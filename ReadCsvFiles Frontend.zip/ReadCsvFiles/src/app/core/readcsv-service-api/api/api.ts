export * from './readCSVFile.service';
import { ReadCSVFileService } from './readCSVFile.service';
export * from './weatherForecast.service';
import { WeatherForecastService } from './weatherForecast.service';
export const APIS = [ReadCSVFileService, WeatherForecastService];
