import { Component, OnInit } from '@angular/core';
import { Book, ReadCSVFileService } from '../core/readcsv-service-api';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.scss'],
})
export class BooksComponent implements OnInit {
  books: Book[] = [];
  bookForm!: FormGroup;
  constructor(private booksService: ReadCSVFileService) {}
  async ngOnInit() {
    await this.getBooks();

    this.bookForm = new FormGroup({
      title: new FormControl(''),
      author: new FormControl(''),
      publicationYear: new FormControl(''),
      genre: new FormControl(''),
      id: new FormControl(''),
    });
  }
  async onBookFormAdd() {
    if (this.bookForm.invalid) return;

    await this.AddBook({
      id: Math.floor(Math.random() * 999999999),
      title: this.title?.value,
      author: this.author?.value,
      publicationYear: this.publicationYear?.value,
      genre: this.genre?.value,
    });
    console.log('form Data submitted');
    await this.getBooks();
  }
  async getBooks() {
    this.books = await this.booksService.getBooks().toPromise();
  }
  async AddBook(book: Book) {
    await this.booksService.addBooks(book).toPromise();
  }

  get id() {
    return this.bookForm.get('id');
  }
  get title() {
    return this.bookForm.get('title');
  }
  get author() {
    return this.bookForm.get('author');
  }
  get publicationYear() {
    return this.bookForm.get('publicationYear');
  }
  get genre() {
    return this.bookForm.get('genre');
  }
}
