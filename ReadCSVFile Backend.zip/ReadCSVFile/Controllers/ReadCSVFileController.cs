﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ReadCSVFile.Database;
using ReadCSVFile.Model;
using ReadCSVFile.Services;

namespace ReadCSVFile.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReadCSVFileController : ControllerBase
    {
        private readonly DataContext _dbContext;
        private readonly ILogger<ReadCSVFileController> _logger;
        public ReadCSVFileController(ILogger<ReadCSVFileController> logger, DataContext dataContext)
        {
            _logger = logger;
            _dbContext = dataContext;
        }

        [HttpGet(Name = "GetFileContent")]
        public async Task<IActionResult> Get()
        {
            var books = ReadFromCSV.ReadBooks();

            return Ok(books);
        }

        [HttpGet("GetBooks", Name = "GetBooks")]
        public async Task<IActionResult> GetBooks()
        {
            var books = _dbContext.Books.ToList();

            return Ok(books);
        }
        [HttpPost("AddBooks", Name = "AddBooks")]
        public async Task<IActionResult> AddBooks(Book book)
        {
            _dbContext.Books.Add(book);
            _dbContext.SaveChanges();

            return Created("GetBooks", book);
        }

    }
}
