﻿using CsvHelper.Configuration.Attributes;

namespace ReadCSVFile.Dto
{
    public class BooksDto
    {

        [Index(0)]
        public int Id { get; set; }

        [Index(1)]
        public string Title { get; set; }

        [Index(2)]
        public string Author { get; set; }

        [Index(3)]
        public string PublicationYear { get; set; }

        [Index(4)]
        public string Genre { get; set; }
    }
}
