﻿using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using ReadCSVFile.Dto;

namespace ReadCSVFile.Services
{
    public static class ReadFromCSV
    {
        public static List<BooksDto> ReadBooks()
        {
            var books = new List<BooksDto>();

            var configuration = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                Delimiter = ",",
                Comment = '#',
                HasHeaderRecord = false
            };

            using (var reader = new StreamReader("C:\\Users\\USER\\source\\repos\\ReadCSVFile\\Content\\books.csv"))
            using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
            {
                books = csv.GetRecords<BooksDto>().ToList();
            }

            return books;
        }
    }
}
